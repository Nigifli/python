def calculateCount(word1: str, word2: str) -> int:
    counter: int = 0

for i in 
