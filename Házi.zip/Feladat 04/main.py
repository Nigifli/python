from consoleIO import *
from helpers import *

name: str = None

name = makeName()
name = color(name)
print(f"Üdvözlöm, {name}")    

