from datetime import datetime

def calculateAge(year: int):
    return datetime.now().year - year